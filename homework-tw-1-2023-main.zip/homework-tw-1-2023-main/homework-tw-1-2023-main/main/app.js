
const  compress=(a, b = true)=> {
	//TODO: implementați funcția
	// TODO: implement the function
	if (typeof a !== 'string' && !(a instanceof String)) {
	  throw new Error('InvalidType');
	}
  
	if (b===true) {
	  let rezultat='';
	  let nr = 1;
	  for (let i = 0; i < a.length; i++) {
		if (a[i] === a[i + 1]) {
		  nr++;
		} else {
		  rezultat = rezultat+ a[i] + nr;
		  nr = 1;
		}
	  }
	  return rezultat;
	} else {
	  let rezultat = '';
	  for (let i = 0; i < a.length; i+=2) {
		const litera = a[i];
		const nr = a[i + 1];
		rezultat += litera.repeat(nr);
	  }
	  return rezultat;
	}
  }
  
  
  module.exports = compress
  